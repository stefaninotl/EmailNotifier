﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailNotifierTester
{
    class Program
    {
        static void Main(string[] args)
        {
            EmailNotifier.EmailNotifier emailNotifier = new EmailNotifier.EmailNotifier();
            emailNotifier.Start(args);
            EmailNotifierConfigMng.Program.Main();         
            Console.ReadLine();
        }
    }
}
