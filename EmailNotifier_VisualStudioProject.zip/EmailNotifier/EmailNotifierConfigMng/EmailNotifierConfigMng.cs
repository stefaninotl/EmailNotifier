﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmailNotifierConfigMng
{
    public partial class EmailNotifierConfigMng : Form
    {
        string namefileDebug = "MyDebugFile.txt";
        string NameFileXMl = "EmailNotifier.xml";
        EmailNotifier.EmailNotifier Myistance = new EmailNotifier.EmailNotifier();
        RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software\\EmailNotifier");
        ServiceController Myservice = new ServiceController("EmailNotifier");
        string pathMyDebugFile = "";
        public EmailNotifierConfigMng()
        {
            InitializeComponent();

            if (File.Exists(Directory.GetCurrentDirectory() + "//" + NameFileXMl))
            {
                EmailNotifier.XMLMng config = EmailNotifier.XMLMng.deserialize(NameFileXMl);
                TextBoxServerName.Text = config.ServerName;
                TextBoxEmail.Text = config.Email;
                TextBoxPassword.Text = config.Password;
                NumeriCupDownPort.Value = Decimal.Parse(config.Port);
                CheckBoxTLSSSL.Checked = Boolean.Parse(config.TLSSSL);
                NumericUpDownCOM.Value = Decimal.Parse(config.COM);
            }

                 
        }
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            EmailNotifier.XMLMng config = new EmailNotifier.XMLMng();
            config.ServerName = TextBoxServerName.Text;
            config.Email = TextBoxEmail.Text;
            config.Password = TextBoxPassword.Text;
            config.Port = NumeriCupDownPort.Value.ToString();
            config.TLSSSL = CheckBoxTLSSSL.Checked.ToString();
            config.COM = NumericUpDownCOM.Value.ToString();
            config.serialize(NameFileXMl);
        }

        private void CheckDebug_Tick(object sender, EventArgs e)
        {
            try
            {

                pathMyDebugFile = (string)registryKey.GetValue("Install_Path") + "\\" + namefileDebug;
                if (File.Exists(pathMyDebugFile))
                {
                    TextBoxDebug.Text = File.ReadAllText(pathMyDebugFile);
                }
                    
            }
            catch
            {
                
            }
            
        }

        private void CheckService_Tick(object sender, EventArgs e)
        {
            Myservice.Refresh();
            LabelServiceStatus.Text = Myservice.Status.ToString();
        }
    }
}
