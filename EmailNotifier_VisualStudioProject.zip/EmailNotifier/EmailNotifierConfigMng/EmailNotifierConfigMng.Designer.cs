﻿namespace EmailNotifierConfigMng
{
    partial class EmailNotifierConfigMng
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmailNotifierConfigMng));
            this.LabelServerName = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CheckBoxTLSSSL = new System.Windows.Forms.CheckBox();
            this.NumeriCupDownPort = new System.Windows.Forms.NumericUpDown();
            this.TextBoxPassword = new System.Windows.Forms.TextBox();
            this.TextBoxEmail = new System.Windows.Forms.TextBox();
            this.TextBoxServerName = new System.Windows.Forms.TextBox();
            this.LabelPort = new System.Windows.Forms.Label();
            this.LabelTLSSSL = new System.Windows.Forms.Label();
            this.LabelPassword = new System.Windows.Forms.Label();
            this.LabelEmail = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.NumericUpDownCOM = new System.Windows.Forms.NumericUpDown();
            this.LabelCom = new System.Windows.Forms.Label();
            this.ButtonSave = new System.Windows.Forms.Button();
            this.CheckDebug = new System.Windows.Forms.Timer(this.components);
            this.TextBoxDebug = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CheckService = new System.Windows.Forms.Timer(this.components);
            this.LabelServiceStatus = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumeriCupDownPort)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumericUpDownCOM)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelServerName
            // 
            this.LabelServerName.BackColor = System.Drawing.Color.White;
            this.LabelServerName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelServerName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelServerName.Location = new System.Drawing.Point(21, 32);
            this.LabelServerName.Name = "LabelServerName";
            this.LabelServerName.Size = new System.Drawing.Size(100, 22);
            this.LabelServerName.TabIndex = 0;
            this.LabelServerName.Text = "Server Name";
            this.LabelServerName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CheckBoxTLSSSL);
            this.groupBox1.Controls.Add(this.NumeriCupDownPort);
            this.groupBox1.Controls.Add(this.TextBoxPassword);
            this.groupBox1.Controls.Add(this.TextBoxEmail);
            this.groupBox1.Controls.Add(this.TextBoxServerName);
            this.groupBox1.Controls.Add(this.LabelPort);
            this.groupBox1.Controls.Add(this.LabelTLSSSL);
            this.groupBox1.Controls.Add(this.LabelPassword);
            this.groupBox1.Controls.Add(this.LabelEmail);
            this.groupBox1.Controls.Add(this.LabelServerName);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(368, 201);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Email Parameter";
            // 
            // CheckBoxTLSSSL
            // 
            this.CheckBoxTLSSSL.AutoSize = true;
            this.CheckBoxTLSSSL.Checked = true;
            this.CheckBoxTLSSSL.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBoxTLSSSL.Location = new System.Drawing.Point(140, 159);
            this.CheckBoxTLSSSL.Name = "CheckBoxTLSSSL";
            this.CheckBoxTLSSSL.Size = new System.Drawing.Size(15, 14);
            this.CheckBoxTLSSSL.TabIndex = 9;
            this.CheckBoxTLSSSL.UseVisualStyleBackColor = true;
            // 
            // NumeriCupDownPort
            // 
            this.NumeriCupDownPort.Location = new System.Drawing.Point(140, 123);
            this.NumeriCupDownPort.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.NumeriCupDownPort.Name = "NumeriCupDownPort";
            this.NumeriCupDownPort.Size = new System.Drawing.Size(56, 22);
            this.NumeriCupDownPort.TabIndex = 8;
            // 
            // TextBoxPassword
            // 
            this.TextBoxPassword.Location = new System.Drawing.Point(140, 92);
            this.TextBoxPassword.MaxLength = 100;
            this.TextBoxPassword.Name = "TextBoxPassword";
            this.TextBoxPassword.PasswordChar = '*';
            this.TextBoxPassword.Size = new System.Drawing.Size(213, 22);
            this.TextBoxPassword.TabIndex = 7;
            this.TextBoxPassword.UseSystemPasswordChar = true;
            // 
            // TextBoxEmail
            // 
            this.TextBoxEmail.Location = new System.Drawing.Point(140, 62);
            this.TextBoxEmail.MaxLength = 100;
            this.TextBoxEmail.Name = "TextBoxEmail";
            this.TextBoxEmail.Size = new System.Drawing.Size(213, 22);
            this.TextBoxEmail.TabIndex = 6;
            // 
            // TextBoxServerName
            // 
            this.TextBoxServerName.Location = new System.Drawing.Point(140, 32);
            this.TextBoxServerName.MaxLength = 100;
            this.TextBoxServerName.Name = "TextBoxServerName";
            this.TextBoxServerName.Size = new System.Drawing.Size(213, 22);
            this.TextBoxServerName.TabIndex = 5;
            // 
            // LabelPort
            // 
            this.LabelPort.BackColor = System.Drawing.Color.White;
            this.LabelPort.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelPort.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPort.Location = new System.Drawing.Point(21, 123);
            this.LabelPort.Name = "LabelPort";
            this.LabelPort.Size = new System.Drawing.Size(100, 22);
            this.LabelPort.TabIndex = 4;
            this.LabelPort.Text = "Port";
            this.LabelPort.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelTLSSSL
            // 
            this.LabelTLSSSL.BackColor = System.Drawing.Color.White;
            this.LabelTLSSSL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelTLSSSL.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelTLSSSL.Location = new System.Drawing.Point(21, 155);
            this.LabelTLSSSL.Name = "LabelTLSSSL";
            this.LabelTLSSSL.Size = new System.Drawing.Size(100, 22);
            this.LabelTLSSSL.TabIndex = 3;
            this.LabelTLSSSL.Text = "TLS/SSL";
            this.LabelTLSSSL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelPassword
            // 
            this.LabelPassword.BackColor = System.Drawing.Color.White;
            this.LabelPassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelPassword.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPassword.Location = new System.Drawing.Point(21, 92);
            this.LabelPassword.Name = "LabelPassword";
            this.LabelPassword.Size = new System.Drawing.Size(100, 22);
            this.LabelPassword.TabIndex = 2;
            this.LabelPassword.Text = "Password";
            this.LabelPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelEmail
            // 
            this.LabelEmail.BackColor = System.Drawing.Color.White;
            this.LabelEmail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelEmail.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelEmail.Location = new System.Drawing.Point(21, 62);
            this.LabelEmail.Name = "LabelEmail";
            this.LabelEmail.Size = new System.Drawing.Size(100, 22);
            this.LabelEmail.TabIndex = 1;
            this.LabelEmail.Text = "Email";
            this.LabelEmail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.NumericUpDownCOM);
            this.groupBox2.Controls.Add(this.LabelCom);
            this.groupBox2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(395, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(368, 83);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Arduino Parameter";
            // 
            // NumericUpDownCOM
            // 
            this.NumericUpDownCOM.Location = new System.Drawing.Point(129, 31);
            this.NumericUpDownCOM.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.NumericUpDownCOM.Name = "NumericUpDownCOM";
            this.NumericUpDownCOM.Size = new System.Drawing.Size(56, 22);
            this.NumericUpDownCOM.TabIndex = 8;
            // 
            // LabelCom
            // 
            this.LabelCom.BackColor = System.Drawing.Color.White;
            this.LabelCom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelCom.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCom.Location = new System.Drawing.Point(11, 31);
            this.LabelCom.Name = "LabelCom";
            this.LabelCom.Size = new System.Drawing.Size(100, 22);
            this.LabelCom.TabIndex = 4;
            this.LabelCom.Text = "COM";
            this.LabelCom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ButtonSave
            // 
            this.ButtonSave.Location = new System.Drawing.Point(12, 227);
            this.ButtonSave.Name = "ButtonSave";
            this.ButtonSave.Size = new System.Drawing.Size(100, 43);
            this.ButtonSave.TabIndex = 11;
            this.ButtonSave.Text = "SAVE";
            this.ButtonSave.UseVisualStyleBackColor = true;
            this.ButtonSave.Click += new System.EventHandler(this.ButtonSave_Click);
            // 
            // CheckDebug
            // 
            this.CheckDebug.Enabled = true;
            this.CheckDebug.Tick += new System.EventHandler(this.CheckDebug_Tick);
            // 
            // TextBoxDebug
            // 
            this.TextBoxDebug.BackColor = System.Drawing.Color.White;
            this.TextBoxDebug.Location = new System.Drawing.Point(395, 106);
            this.TextBoxDebug.Multiline = true;
            this.TextBoxDebug.Name = "TextBoxDebug";
            this.TextBoxDebug.ReadOnly = true;
            this.TextBoxDebug.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBoxDebug.Size = new System.Drawing.Size(368, 107);
            this.TextBoxDebug.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(575, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Service Status";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CheckService
            // 
            this.CheckService.Enabled = true;
            this.CheckService.Interval = 1000;
            this.CheckService.Tick += new System.EventHandler(this.CheckService_Tick);
            // 
            // LabelServiceStatus
            // 
            this.LabelServiceStatus.BackColor = System.Drawing.Color.White;
            this.LabelServiceStatus.Location = new System.Drawing.Point(689, 237);
            this.LabelServiceStatus.MaxLength = 100;
            this.LabelServiceStatus.Multiline = true;
            this.LabelServiceStatus.Name = "LabelServiceStatus";
            this.LabelServiceStatus.ReadOnly = true;
            this.LabelServiceStatus.ShortcutsEnabled = false;
            this.LabelServiceStatus.Size = new System.Drawing.Size(75, 21);
            this.LabelServiceStatus.TabIndex = 10;
            // 
            // EmailNotifierConfigMng
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 282);
            this.Controls.Add(this.LabelServiceStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TextBoxDebug);
            this.Controls.Add(this.ButtonSave);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 320);
            this.MinimumSize = new System.Drawing.Size(800, 320);
            this.Name = "EmailNotifierConfigMng";
            this.Text = "EmailNotifier";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumeriCupDownPort)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.NumericUpDownCOM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelServerName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox CheckBoxTLSSSL;
        private System.Windows.Forms.NumericUpDown NumeriCupDownPort;
        private System.Windows.Forms.TextBox TextBoxPassword;
        private System.Windows.Forms.TextBox TextBoxEmail;
        private System.Windows.Forms.TextBox TextBoxServerName;
        private System.Windows.Forms.Label LabelPort;
        private System.Windows.Forms.Label LabelTLSSSL;
        private System.Windows.Forms.Label LabelPassword;
        private System.Windows.Forms.Label LabelEmail;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown NumericUpDownCOM;
        private System.Windows.Forms.Label LabelCom;
        private System.Windows.Forms.Button ButtonSave;
        private System.Windows.Forms.Timer CheckDebug;
        private System.Windows.Forms.TextBox TextBoxDebug;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer CheckService;
        private System.Windows.Forms.TextBox LabelServiceStatus;
    }
}

