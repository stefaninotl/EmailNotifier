﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.ServiceProcess;
using System.Threading.Tasks;

namespace EmailNotifier
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
            this.serviceInstallerEmailNotifier.AfterInstall += ServiceManagement_AfterInstall;
        }
        static void ServiceManagement_AfterInstall(object sender, InstallEventArgs e)
        {
            new ServiceController("EmailNotifier").Start();
        }
        public override void Install(System.Collections.IDictionary stateSaver)
        {
            base.Install(stateSaver);
            string path = this.Context.Parameters["assemblypath"];
            path = path.Remove(path.Length - 18);
            Microsoft.Win32.RegistryKey key;
            key = Microsoft.Win32.Registry.LocalMachine.CreateSubKey("Software\\EmailNotifier");
            key.SetValue("Install_Path", path);
            key.Close();
        }
    }
}
