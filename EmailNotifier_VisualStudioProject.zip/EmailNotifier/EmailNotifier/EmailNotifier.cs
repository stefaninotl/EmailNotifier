﻿using System;
using System.Timers;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using ComponentPro;
using ComponentPro.Net;
using ComponentPro.Net.Mail;
using System.IO;
using Microsoft.Win32;

namespace EmailNotifier
{
    public partial class EmailNotifier : ServiceBase
    {
        string ServerEmail = "";
        string Email = "";
        string Password = "";
        int Port = 0;
        string Com = "0";
        SecurityMode securityMode = SecurityMode.Implicit;
        public string MyDebug = "";
        public string pathMyDebugFile = "";
        string pathName = "";
        string namefileDebug = "MyDebugFile.txt";
        string NameFileXMl = "EmailNotifier.xml";
        public StreamWriter MyDebugFile;
        public EmailNotifier()
        {
            InitializeComponent();
        }
        private Timer m_mainTimer;

        public void Start(string[] args)
        {
            try
            {
                //
                // Create and start a timer.
                //
                m_mainTimer = new Timer();
                m_mainTimer.Interval = 5000;   // every one 5s
                m_mainTimer.Elapsed += M_mainTimer_Elapsed;
                m_mainTimer.AutoReset = true;  // makes it fire only once
                m_mainTimer.Start(); // Start
            }
            catch (Exception ex)
            {
                // omitted
            }
        }

        public void M_mainTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ArduinoControllerMain Ard = new ArduinoControllerMain();
            pathMyDebugFile = readRegisterkey() + "\\" + namefileDebug;
            pathName = readRegisterkey() + "\\" + NameFileXMl;
            if (File.Exists(pathMyDebugFile))
            {
                FileInfo FileInfo = new FileInfo(pathMyDebugFile);
                var size = FileInfo.Length;
                if (size > 150)
                {
                    File.Delete(pathMyDebugFile);
                }
            }
            if (File.Exists(pathName))
            {
                try
                {
                    XMLMng config = XMLMng.deserialize(pathName);
                    ServerEmail = config.ServerName;
                    Email = config.Email;
                    Password = config.Password;
                    Port = int.Parse(config.Port);
                    Com = "COM" + config.COM;
                    if (Boolean.Parse(config.TLSSSL))
                    {
                        securityMode = SecurityMode.Implicit;
                    }

                    else
                    {
                        securityMode = SecurityMode.None;
                    }
                    

                    
                    
                    Ard.SetComPort(CheckUnreadEmail(),Com);
                }
                catch (Exception ex)
                {
                    Ard.currentPort.Close();
                    Console.WriteLine(ex.Message);
                    MyDebug = ex.Message;
                    writefile(MyDebug);
                }
            }
        }
        protected override void OnStart(string[] args)
        {
            Start(args);
        }

        protected override void OnStop()
        {
            try
            {
                // Service stopped. Also stop the timer.
                m_mainTimer.Stop();
                m_mainTimer.Dispose();
                m_mainTimer = null;
            }
            catch (Exception ex)
            {
                // omitted
            }
        }


        public bool CheckUnreadEmail()
        {
            // Create a new instance of the ImapClient class.
            Imap ImapClient = new Imap();
            // Connect to the server.
            ImapClient.Connect(ServerEmail, Port, securityMode);

            // Login to the server.
            ImapClient.Authenticate(Email, Password);

            // Select 'INBOX' mailbox
            ImapClient.Select("INBOX");

            // Get the message list.
            ImapMessageCollection list = ImapClient.ListMessages(ImapEnvelopeParts.UniqueId | ImapEnvelopeParts.Size, ImapCriterion.DontHaveFlags(ImapMessageFlags.Seen));
            if (list.Count> 0)
            {
                Console.WriteLine("Message present");
                MyDebug = ("Message present");
                writefile(MyDebug);
                ImapClient.Disconnect();
                return true;       
            }
            else
            {
                Console.WriteLine("Message not present");
                MyDebug = ("Message not present");
                writefile(MyDebug);
                ImapClient.Disconnect();
                return false;              
            }
          
        }

        public void writefile (string text)
        {
            
            pathMyDebugFile = readRegisterkey() + "\\" + namefileDebug;
            MyDebugFile = File.AppendText(pathMyDebugFile);
            MyDebugFile.WriteLine(text);
            MyDebugFile.Close();
        }
        public string readRegisterkey()
        {
            RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software\\EmailNotifier");
            string path = (string)registryKey.GetValue("Install_Path");
            return path;
        }

    }
}
