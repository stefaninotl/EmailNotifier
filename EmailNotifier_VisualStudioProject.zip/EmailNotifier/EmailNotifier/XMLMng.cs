﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace EmailNotifier
{
    public class XMLMng
    {
 
        public string ServerName;
        public string Email;
        public string Password;
        public string Port;
        public string TLSSSL;
        public string COM;


        public void serialize(string Filename)
        {
            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(typeof(XMLMng));

            using (TextWriter tw = new StreamWriter(Filename))
            {
                XmlSerializerNamespaces a = new XmlSerializerNamespaces();
                x.Serialize(tw, this, a);
            }

        }
        public static XMLMng deserialize(string Filename)
        {
            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(typeof(XMLMng));
            XMLMng config = null;
            using (TextReader tr = new StreamReader(Filename))
            {
                config = (XMLMng)x.Deserialize(tr);
   
            }
            return config;
        }
    }
}
