﻿using System;
using System.Threading;
using System.IO.Ports;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailNotifier
{
    public class ArduinoControllerMain
    {
        public SerialPort currentPort;
        EmailNotifier Myistance = new EmailNotifier();
        public void SetComPort(bool NewEmail, string Com)
        {
            currentPort = new SerialPort(Com, 9600);
            byte[] buffer = new byte[1];
            currentPort.Open();
            if (currentPort.IsOpen)
            {
                if (NewEmail)
                {
                    buffer[0] = Convert.ToByte(1);
                }
                else
                {
                    buffer[0] = Convert.ToByte(0);
                }
                currentPort.Write(buffer, 0, 1);
                currentPort.Close();
                System.Console.WriteLine("Telegram sended");
                Myistance.MyDebug = "Telegram sended";
                Myistance.writefile(Myistance.MyDebug);
            }
            else
            {
                System.Console.WriteLine("Port not open");
                Myistance.MyDebug = "Port not open";
                Myistance.writefile(Myistance.MyDebug);
            }

        }

    }
}
